﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("O animal é um mamífero? (S/N): ");
        bool mamifero = Console.ReadLine().ToUpper() == "S";

        if (mamifero)
        {
            Console.Write("É quadrúpede? (S/N): ");
            bool quadrupede = Console.ReadLine().ToUpper() == "S";

            if (quadrupede)
            {
                Console.Write("É carnívoro? (S/N): ");
                bool carnivoro = Console.ReadLine().ToUpper() == "S";
                Console.WriteLine($"O animal escolhido foi: {(carnivoro ? "Leão" : "Cavalo")}");
            }
            else
            {
                Console.Write("É bípede? (S/N): ");
                bool bipede = Console.ReadLine().ToUpper() == "S";
                if (bipede)
                {
                    Console.Write("É onívoro? (S/N): ");
                    bool onivoro = Console.ReadLine().ToUpper() == "S";
                    Console.WriteLine($"O animal escolhido foi: {(onivoro ? "Homem" : "Macaco")}");
                }
                else
                {
                    Console.WriteLine("O animal escolhido foi: Morcego ou Baleia");
                }
            }
        }
        else
        {
            Console.Write("O animal é uma ave? (S/N): ");
            bool ave = Console.ReadLine().ToUpper() == "S";

            if (ave)
            {
                Console.Write("A ave é não-voadora? (S/N): ");
                bool naoVoadora = Console.ReadLine().ToUpper() == "S";
                if (naoVoadora)
                {
                    Console.Write("O habitat é tropical? (S/N): ");
                    bool tropical = Console.ReadLine().ToUpper() == "S";
                    Console.WriteLine($"O animal escolhido foi: {(tropical ? "Avestruz" : "Pinguim")}");
                }
                else
                {
                    Console.Write("A ave é nadadora? (S/N): ");
                    bool nadadora = Console.ReadLine().ToUpper() == "S";
                    Console.WriteLine($"O animal escolhido foi: {(nadadora ? "Pato" : "Águia")}");
                }
            }
            else
            {
                Console.WriteLine("Animal não identificado.");
            }
        }
    }
}
