﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite o número de horas trabalhadas no mês: ");
        int horasTrabalhadas = int.Parse(Console.ReadLine());

        Console.Write("Digite o salário por hora: ");
        double salarioPorHora = double.Parse(Console.ReadLine());

        int horasNormais = 40 * 4;
        int horasExtras = Math.Max(0, horasTrabalhadas - horasNormais);
        double salarioTotal = (horasNormais * salarioPorHora) + (horasExtras * salarioPorHora * 1.5);

        Console.WriteLine($"O salário total é: R$ {salarioTotal:F2}");
    }
}
