﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite um número de 1 a 7: ");
        int numero = int.Parse(Console.ReadLine());

        string diaSemana = numero switch
        {
            1 => "Domingo",
            2 => "Segunda-feira",
            3 => "Terça-feira",
            4 => "Quarta-feira",
            5 => "Quinta-feira",
            6 => "Sexta-feira",
            7 => "Sábado",
            _ => "Número inválido"
        };

        Console.WriteLine($"O dia da semana correspondente é: {diaSemana}");
    }
}
